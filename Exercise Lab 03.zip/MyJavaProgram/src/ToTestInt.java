// Define the interface Test
interface Test {
    int square(int num);
}

// Implement the interface Test in the Arithmetic class
class Arithmetic implements Test {
    @Override
    public int square(int num) {
        return num * num;
    }
}

// Create a new class ToTestInt
class ToTestInt {
    public static void main(String[] args) {
        // Create an object of the Arithmetic class
        Arithmetic arithmeticObj = new Arithmetic();

        // Use the object to calculate the square
        int result = arithmeticObj.square(5);

        // Display the result
        System.out.println("Square of 5 is: " + result);
    }
}