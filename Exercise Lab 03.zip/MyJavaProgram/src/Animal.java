
class animal{
    static int num = 0;
    String name;
    int age;
    public animal(String name, int age)
    {
        this.name = name;
        this.age = age;
        num = num+1;
    }
    static int getnum(){
        return num;
    }
    void info(){
        System.out.println("Name= "  +name);
         System.out.println("Age= "  +age);
    }
}

public class Animal {
    public static void main(String[] args) {
        animal obj1 = new animal("kitty", 6);
        animal obj2 = new animal("puppy", 7);
        
        // display info of instance method
        obj1.info();
        obj2.info();
        // call static method
        int totalanimal = animal.getnum();
          System.out.println("Total animals are "+totalanimal  );
}
}
