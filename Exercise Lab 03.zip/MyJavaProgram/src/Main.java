 
class myclass{
    int num;
    public myclass(int num)
    {
        this.num =num;
    }
    public int getnum(){
        return this.num;
    }
}
public class Main {
    public static void main(String[] args) {
        myclass obj = new myclass(98);
        int result = obj.getnum();
        System.out.println("The value of number is "+result );
    }
}
