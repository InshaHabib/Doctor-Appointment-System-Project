
class animal1 {
    String sound = "Animal Sound";

    void makeSound() {
        System.out.println(sound);
    }
}

class Dog extends Animal1  {
    String sound = "Bark";

    void makeSound() {
        System.out.println(sound);
        System.out.println(super.sound);
        // Using 'super' to access the superclass's sound
    }
}

public class SuperKeywordExample {
    public static void main(String[] args) {
        Dog myDog = new Dog();
        myDog.makeSound();
    }
}