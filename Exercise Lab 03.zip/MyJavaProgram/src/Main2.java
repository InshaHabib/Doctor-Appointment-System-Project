// Define the interface A
interface A {
    void meth1();
    void meth2();
}

// Implement the interface A in MyClass
class MyClass implements A {
    @Override
    public void meth1() {
        // Implementation for meth1
        System.out.println("Method 1 implementation in MyClass");
    }

    @Override
    public void meth2() {
        // Implementation for meth2
        System.out.println("Method 2 implementation in MyClass");
    }
}

public class Main2 {
    public static void main(String[] args) {
        // Create an object of MyClass
        MyClass myObj = new MyClass();

        // Call the methods of MyClass
        myObj.meth1();
        myObj.meth2();
    }
}